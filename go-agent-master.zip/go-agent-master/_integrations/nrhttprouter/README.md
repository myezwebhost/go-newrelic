# _integrations/nrhttprouter [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrhttprouter?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrhttprouter)

Package `nrhttprouter` instruments https://github.com/julienschmidt/httprouter applications.

```go
import "github.com/newrelic/go-agent/_integrations/nrhttprouter"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrhttprouter).
