# _integrations/nrawssdk/v1 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v1?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v1)

Package `nrawssdk` instruments https://github.com/aws/aws-sdk-go requests.

```go
import "github.com/newrelic/go-agent/_integrations/nrawssdk/v1"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v1).
