// Copyright 2020 New Relic Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

// Package newrelic provides instrumentation for Go applications.
//
// Deprecated: This package has been supplanted by version 3 here:
//
// https://godoc.org/github.com/newrelic/go-agent/v3/newrelic
package newrelic
